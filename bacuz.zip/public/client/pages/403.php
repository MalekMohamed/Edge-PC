<?php
$title = 'Forbidden - Error 403';
require 'public/client/header.php';
?><div class="row">
    <div class="col-sm-12">
        <div class="ex-page-content text-center">

            <h2>You don`t have the permission to enter this page</h2>
            <br>
            <a class="btn btn-default waves-effect waves-light" data-animation="fadein" data-plugin="custommodal" data-overlayspeed="200"
               data-overlaycolor="#36404a" href=".login-model"><i class="fa fa-sign-in"></i> Login</a>
<script>
    jQuery('btn').click();
</script>
        </div>
    </div>
</div>