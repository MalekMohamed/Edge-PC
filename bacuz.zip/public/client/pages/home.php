<?php
/**
 * Created by PhpStorm.
 * User: Strix
 * Date: 2/13/2019
 * Time: 1:59 PM
 */
include('public/client/pages/index.php');